/* a trivial function used to test building shared libraries */

int foo(void)
{
	return 1;
}
