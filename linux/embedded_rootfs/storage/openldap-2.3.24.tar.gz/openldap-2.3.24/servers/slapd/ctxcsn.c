/* ctxcsn.c -- Context CSN Management Routines */
/* $OpenLDAP: pkg/ldap/servers/slapd/ctxcsn.c,v 1.31.2.7 2006/01/03 22:16:14 kurt Exp $ */
/* This work is part of OpenLDAP Software <http://www.openldap.org/>.
 *
 * Copyright 2003-2006 The OpenLDAP Foundation.
 * Portions Copyright 2003 IBM Corporation.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted only as authorized by the OpenLDAP
 * Public License.
 *
 * A copy of this license is available in the file LICENSE in the
 * top-level directory of the distribution or, alternatively, at
 * <http://www.OpenLDAP.org/license.html>.
 */

#include "portable.h"

#include <stdio.h>

#include <ac/string.h>
#include <ac/socket.h>

#include "lutil.h"
#include "slap.h"
#include "lutil_ldap.h"

const struct berval slap_ldapsync_bv = BER_BVC("ldapsync");
const struct berval slap_ldapsync_cn_bv = BER_BVC("cn=ldapsync");

void
slap_get_commit_csn(
	Operation *op,
	struct berval *maxcsn,
	struct berval *curcsn
)
{
	struct slap_csn_entry *csne, *committed_csne = NULL;

	if ( maxcsn ) {
		BER_BVZERO( maxcsn );
	}

	ldap_pvt_thread_mutex_lock( op->o_bd->be_pcl_mutexp );

	LDAP_TAILQ_FOREACH( csne, op->o_bd->be_pending_csn_list, ce_csn_link ) {
		if ( csne->ce_opid == op->o_opid && csne->ce_connid == op->o_connid ) {
			if ( curcsn ) *curcsn = csne->ce_csn;
			csne->ce_state = SLAP_CSN_COMMIT;
			break;
		}
	}

	LDAP_TAILQ_FOREACH( csne, op->o_bd->be_pending_csn_list, ce_csn_link ) {
		if ( csne->ce_state == SLAP_CSN_COMMIT ) committed_csne = csne;
		if ( csne->ce_state == SLAP_CSN_PENDING ) break;
	}

	if ( committed_csne && maxcsn ) *maxcsn = committed_csne->ce_csn;
	ldap_pvt_thread_mutex_unlock( op->o_bd->be_pcl_mutexp );
}

void
slap_rewind_commit_csn( Operation *op )
{
	struct slap_csn_entry *csne;

	ldap_pvt_thread_mutex_lock( op->o_bd->be_pcl_mutexp );

	LDAP_TAILQ_FOREACH( csne, op->o_bd->be_pending_csn_list, ce_csn_link ) {
		if ( csne->ce_opid == op->o_opid && csne->ce_connid == op->o_connid ) {
			csne->ce_state = SLAP_CSN_PENDING;
			break;
		}
	}

	ldap_pvt_thread_mutex_unlock( op->o_bd->be_pcl_mutexp );
}

void
slap_graduate_commit_csn( Operation *op )
{
	struct slap_csn_entry *csne;

	if ( op == NULL ) return;
	if ( op->o_bd == NULL ) return;

#if 0
	/* it is NULL when we get here from the frontendDB;
	 * alternate fix: initialize frontendDB like all other backends */
	assert( op->o_bd->be_pcl_mutexp != NULL );
#endif
	
	if ( op->o_bd->be_pcl_mutexp == NULL ) return;

	ldap_pvt_thread_mutex_lock( op->o_bd->be_pcl_mutexp );

	LDAP_TAILQ_FOREACH( csne, op->o_bd->be_pending_csn_list, ce_csn_link ) {
		if ( csne->ce_opid == op->o_opid && csne->ce_connid == op->o_connid ) {
			LDAP_TAILQ_REMOVE( op->o_bd->be_pending_csn_list,
				csne, ce_csn_link );
			if ( op->o_csn.bv_val == csne->ce_csn.bv_val ) {
				BER_BVZERO( &op->o_csn );
			}
			ch_free( csne->ce_csn.bv_val );
			ch_free( csne );
			break;
		}
	}

	ldap_pvt_thread_mutex_unlock( op->o_bd->be_pcl_mutexp );

	return;
}

static struct berval ocbva[] = {
	BER_BVC("top"),
	BER_BVC("subentry"),
	BER_BVC("syncProviderSubentry"),
	BER_BVNULL
};

Entry *
slap_create_context_csn_entry(
	Backend *be,
	struct berval *context_csn )
{
	Entry* e;

	struct berval bv;

	e = (Entry *) ch_calloc( 1, sizeof( Entry ));

	attr_merge( e, slap_schema.si_ad_objectClass,
		ocbva, NULL );
	attr_merge_one( e, slap_schema.si_ad_structuralObjectClass,
		&ocbva[1], NULL );
	attr_merge_one( e, slap_schema.si_ad_cn,
		(struct berval *)&slap_ldapsync_bv, NULL );

	if ( context_csn ) {
		attr_merge_one( e, slap_schema.si_ad_contextCSN,
			context_csn, NULL );
	}

	BER_BVSTR( &bv, "{}" );
	attr_merge_one( e, slap_schema.si_ad_subtreeSpecification, &bv, NULL );

	build_new_dn( &e->e_name, &be->be_nsuffix[0],
		(struct berval *)&slap_ldapsync_cn_bv, NULL );
	ber_dupbv( &e->e_nname, &e->e_name );

	return e;
}

void
slap_queue_csn(
	Operation *op,
	struct berval *csn )
{
	struct slap_csn_entry *pending;

	pending = (struct slap_csn_entry *) ch_calloc( 1,
			sizeof( struct slap_csn_entry ));
	ldap_pvt_thread_mutex_lock( op->o_bd->be_pcl_mutexp );

	ber_dupbv( &pending->ce_csn, csn );
	ber_dupbv_x( &op->o_csn, &pending->ce_csn, op->o_tmpmemctx );
	pending->ce_connid = op->o_connid;
	pending->ce_opid = op->o_opid;
	pending->ce_state = SLAP_CSN_PENDING;
	LDAP_TAILQ_INSERT_TAIL( op->o_bd->be_pending_csn_list,
		pending, ce_csn_link );
	ldap_pvt_thread_mutex_unlock( op->o_bd->be_pcl_mutexp );
}

int
slap_get_csn(
	Operation *op,
	struct berval *csn,
	int manage_ctxcsn )
{
	if ( csn == NULL ) return LDAP_OTHER;

#ifndef HAVE_GMTIME_R
	ldap_pvt_thread_mutex_lock( &gmtime_mutex );
#endif
	csn->bv_len = lutil_csnstr( csn->bv_val, csn->bv_len, 0, 0 );
#ifndef HAVE_GMTIME_R
	ldap_pvt_thread_mutex_unlock( &gmtime_mutex );
#endif

	if ( manage_ctxcsn )
		slap_queue_csn( op, csn );

	return LDAP_SUCCESS;
}
